import requests
import mysql.connector
from mysql.connector import Error
import re
import csv

class gestioneDB:
    def __init__(self):
        self.conn = mysql.connector.connect(user='root', password='', host='localhost', database='dbbot')
        self.cursor=self.conn.cursor()
            

    def insertImpianti(name):    
        conn = mysql.connector.connect(user='root', password='', host='localhost', database='dbbot')
        cursor=conn.cursor()
        cursor.reset()
        with open(name, 'r',encoding="utf-8") as file:
            reader = csv.reader(file,delimiter=";")
            next(reader) # salto la prima riga (header)
            next(reader)
            for riga in reader:
                query="INSERT INTO impianti VALUES"                
                lista_senza_apostrofi = [elemento.replace("'", "") for elemento in riga]
                query+="('"+lista_senza_apostrofi[0]+"','"+lista_senza_apostrofi[1]+"','"+lista_senza_apostrofi[2]+"','"+lista_senza_apostrofi[3]+"','"+lista_senza_apostrofi[4]+"','"+lista_senza_apostrofi[5]+"','"+lista_senza_apostrofi[6]+"','"+lista_senza_apostrofi[7]+"','"+lista_senza_apostrofi[8]+"','"+lista_senza_apostrofi[9]+"')"
                string=re.sub("/","",query) 
                cursor.execute(string)                
                query+=","
                conn.commit()
                query=""
            
        conn.close()

    def insertPrezzi(name):    
        conn = mysql.connector.connect(user='root', password='', host='localhost', database='dbbot')
        cursor=conn.cursor()
        cursor.reset()
        with open(name, 'r',encoding="utf-8") as file:
            reader = csv.reader(file,delimiter=";")
            next(reader) # salto la prima riga (header)
            next(reader)
            for riga in reader:
                query="INSERT INTO prezzi VALUES"                
                lista_senza_apostrofi = [elemento.replace("'", "") for elemento in riga]
                query+="('"+lista_senza_apostrofi[0]+"','"+lista_senza_apostrofi[1]+"','"+lista_senza_apostrofi[2]+"','"+lista_senza_apostrofi[3]+"','"+lista_senza_apostrofi[4]+"')"
                string=re.sub("/","",query) 
                cursor.execute(string)                
                query+=","
                conn.commit()
                query=""
            
        conn.close()



