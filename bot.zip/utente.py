import mysql.connector
from calcoloDistanza import *

def start(chatID,username):
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='dbbot')
    cursor=conn.cursor()
    query=f"select * from utente where IDchat = '{chatID}'"
    cursor.execute(query)
    result = cursor.fetchmany()
    if len(result)>0:
        return help()
    else:
        query=f"INSERT INTO utente (IDchat,username) VALUES ({chatID},'{username}');"
        cursor.execute(query)
        conn.commit()
        query=f"select * from utente where IDchat = '{chatID}'"
        cursor.execute(query)
        conn.commit()
        return help()

def setCapienza(chatID,capienza):
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='dbbot')
    cursor=conn.cursor()
    capienza=int(capienza)
    if  capienza>=5 and capienza<=200:
        query=f"UPDATE utente SET capienza={capienza} WHERE chatID={chatID}; "
        cursor.execute(query)
        result = cursor.fetchmany()
        return result
    else:
        return "manda un dato reale min 5 max 200"
    
def setTipologia(chatID,tipologia):
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='dbbot')
    cursor=conn.cursor()
    if tipologia in ["BENZINA","DIESEL","GPL","METANO"]:
        query=f"UPDATE utente SET tipologia='{tipologia}' WHERE chatID={chatID}; "
        cursor.execute(query)
        conn.commit()
        return "eseguito con successo"
    else:
        return "scegli uno tra diesel,benzina,gpl e metano"
    
def setConsumo(chatID,consumo):
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='dbbot')
    cursor=conn.cursor()
    consumo=int(consumo)
    if consumo>=5 and consumo<=20:
        query=f"UPDATE users SET consumo={consumo} WHERE chatID={chatID}; "
        cursor.execute(query)
        conn.commit()
        return "eseguito con successo"
    else:
        return "il valore ddeve essere compreso tra 5 e 20"
    
def issetVar(chatID):
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='dbbot')
    cursor=conn.cursor()
    query=f"select * from users where chatID = '{chatID}';"
    cursor.execute(query)
    result = cursor.fetchmany()
    if len(result)>0:
        for x in result[0]:
            if x == "" or x == 0:
                return False
    return True

def dati(chatID):
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='dbbot')
    cursor=conn.cursor()
    query=f"select tipologia,consumo,capienza from users where chatID = '{chatID}'"
    cursor.execute(query)
    result = cursor.fetchmany()
    return result[0]

def ricerca(chatID,latitude,longitude):
    conn = mysql.connector.connect(user='root', password='', host='localhost', database='dbbot')
    cursor=conn.cursor()
    if(not issetVar(chatID)):
        return "devi prima inserire i dati"
    else:
        conveniente=0
        spesaMin=100000000
        utente=dati(880180377)
        tipo=utente[0]
        query=f'''SELECT latitudine,longitudine,gestore,prezzo,
                    (6371000 * Acos (Cos (Radians({latitude})) * Cos(Radians(latitude)) *
                                        Cos(Radians(longitude) - Radians({longitude}))
                                        + Sin (Radians({latitude})) *
                                            Sin(Radians(latitude)))
                    ) AS dist
                FROM   impianti join prezzi on impianti.idImppianto=prezzi.idImpianto
                where tipologia="{tipo}"
                ORDER  BY dist 
                LIMIT  15;'''
        cursor.execute(query)
        result = cursor.fetchmany()
        for var in result:
            spesa=costoEffettivo(utente[1],var[3],calcola_distanza(latitude,longitude,var[0],var[1]),utente[2])
            if(spesa<spesaMin):
                spesaMin=spesa
                conveniente=var

        return conveniente

def costoEffettivo(consumo,prezzo,distanza,litri):
    lkm=1/consumo
    spesa=litri*prezzo
    spesa+=distanza*lkm*prezzo
    return spesa


def calcola_distanza(latitudine_inizio, longitudine_inizio, latitudine_fine, longitudine_fine):
    dati_percorso = calcola_percorso(latitudine_inizio, longitudine_inizio, latitudine_fine, longitudine_fine)
    distanza_in_metri = dati_percorso["features"][0]["properties"]["summary"]["distance"]
    distanza_in_chilometri = distanza_in_metri / 1000
    return distanza_in_chilometri



def help():
    return "i comandi sono:\n/tipologia x\n/capienza x\n/consumo x(km/l)\n"



    