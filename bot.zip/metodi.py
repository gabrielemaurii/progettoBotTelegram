def extract(message,command):
    message=message.replace(" ","")
    message=message.replace(command,"")
    return message