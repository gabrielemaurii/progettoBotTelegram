import requests
import json
import mysql.connector
from calcoloDistanza import *


class Telegram:
    
    def __init__(self):
        self.bot_token ="6224212161:AAF5mEaA_c18e_eciCn77cX2aj1ubj8L350"
        self.base_url = f'https://api.telegram.org/bot{self.bot_token}'
        self.ultimo_msg=0
        #self.utlimo_msg

    def get_updates(self):
        result=requests.post(self.base_url+"getUpdates")
        if result.status_code==200:
            result=result.json()
            if result["ok"]:
                try:
                    requests.post(self.base_url+"getUpdates",params={"offset": result["result"][-1]["update_id"]+1})
                    return [message["message"] for message in result["result"]]
                except:
                    return False
        return False

    def sendMessage(self,chatID,messaggio="ciao"):
        requests.get(self.base_url+"sendMessage",params={"chat_id":chatID,"text":messaggio})
        return True

    def sendPosition(self,chat_id, latitude, longitude):
        params = {
            'chat_id': chat_id,
            'latitude': latitude,
            'longitude': longitude
        }
        requests.get(self.base_url+"sendLocation", params=params)


