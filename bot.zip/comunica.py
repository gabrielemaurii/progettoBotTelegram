from gestioneDB import *
from myTelegram import *
from metodi import *
from utente import *
import time

def comunica():
    MyTelegram = Telegram() 

    while True:
        response="non ho capito"

        messages = MyTelegram.get_updates()
        if(messages):
            for message in messages:
                chatID = message["chat"]["id"]  
                try:
                    response=ricerca(chatID,message["location"]["latitude"],message["location"]["longitude"])
                    MyTelegram.sendPosition(chatID,response[0],response[1])

                except:
                    try:
                        message = str(message["text"]).lower()
                        if(message.find("/start")!=-1):
                            myid=start(chatID,message["chat"]["username"])
                            MyTelegram.sendMessage(chatID,myid)
                        
                        if(message.find("/help")!=-1):
                            response=help()
                            
                        if(message.find("/tipologia")!=-1):
                            response=setTipologia(chatID,extract(message,"/tipologia"))

                        if(message.find("/capienza")!=-1):
                            response=setCapienza(chatID,extract(message,"/capienza"))

                        if(message.find("/consumo")!=-1):
                            response=setConsumo(chatID,extract(message,"/consumo"))
                    
                    except:response="non ho capito"
                    MyTelegram.sendMessage(chatID,response)
        time.sleep(1)
