from threading import Thread
from comunica import *
while True:
    comunica()
