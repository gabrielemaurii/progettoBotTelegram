from gestioneCSV import *
from connessione import *






gest=gestione.lettura()



