import mysql.connector
import csv
class gestioneDB:
    def __init__(self):
        self.conn = mysql.connector.connect(user='root', password='', host='localhost', database='dbbot')
        self.cursor = self.conn.cursor()

    def closeConnection(self):
        self.conn.close()
    
    def scriviSulDBPrezzi(self,name):
        with open(name, 'r') as csv_file:
            reader = csv.reader(csv_file)
            csv_file.readline
            csv_file.readline
            for row in reader:
                dati=(row[0],row[1],row[2],row[3],row[4])
                sql='INSERT INTO prezzi (idImpianto, descCarburante,prezzo,isSelf,dtComu) VALUES (%s, %s,%s,%s,%s)'
                self.cursor.execute(sql,dati)
            self.conn.commit()

    def scriviSulDBImpianti(self,name):
        with open(name, 'r') as csv_file:
            reader = csv.reader(csv_file)
            csv_file.readline
            csv_file.readline
            for row in reader:
                dati=(row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8])
                sql='INSERT INTO impianti (ID, gestore,bandiera,tipoImpianto,nomeImpianto,indirizzo,comune,provincia,latitudine,longitudine) VALUES (%s, %s,%s,%s,%s,%s,%s,%s,%s,%s)'
                self.cursor.execute(sql,dati)
            self.conn.commit()
            
    
    #def addImpianti(self,ID, gestore,bandiera,tipoImpianto,nomeImpianto,indirizzo,comune,provincia,latitudine,longitudine):
        #self.cursor.execute('INSERT INTO impianti (ID, gestore,bandiera,tipoImpianto,nomeImpianto,indirizzo,comune,provincia,latitudine,longitudine) VALUES ()')
