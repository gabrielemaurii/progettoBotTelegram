import csv
from connessione import*
class gestione:
    def __init__(self,filenameImpianti, filenamePrezzi) :
        self.filenameImpianti=filenameImpianti
        self.filenamePrezzi=filenamePrezzi

    def lettura(self):
        if line_count >1:
            gestioneDB.scriviSulDB(self.filenameImpianti)
                    ## carico i dati sul db
           ## print(f'Processed {line_count} lines.')

        with open(self.filenamePrezzi) as csv_file:
            prezzi=[]
            csv_reader = csv.reader(csv_file, delimiter=';')
            line_count = 0
            for row in csv_reader:
                if line_count >1:
                    prezzi=
            
            gestioneDB.scriviSulDB(prezzi)
                    ## carico i dati sul db
            ##print(f'Processed {line_count} lines.')

    