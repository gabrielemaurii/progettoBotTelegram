import requests
from calcoloDistanza import *


class Telegram:
    
    def __init__(self):
        self.bot_token ="6224212161:AAF5mEaA_c18e_eciCn77cX2aj1ubj8L350"
        self.base_url = f'https://api.telegram.org/bot{self.bot_token}'
        #self.utlimo_msg

    def get_updates(self):
        result=requests.get(self.base_url+"/getUpdates")
        if result.status_code==200:
            dati=result.json()
            if dati["ok"]:
                try:
                    off = dati["result"][-1]["update_id"]+1
                    requests.get(self.base_url+"/getUpdates",params={"offset": off})
                    return [message["message"] for message in dati["result"]]
                    
                
                except Exception as e:
                    e
                    return False
            

    def sendMessage(self,chatID,messaggio="ciao"):
        requests.get(self.base_url+"/sendMessage",params={"chat_id":chatID,"text":messaggio})
        return True

    def sendPosition(self,chat_id, latitude, longitude):
        params = {
            'chat_id': chat_id,
            'latitude': latitude,
            'longitude': longitude
        }
        requests.get(self.base_url+"sendLocation", params=params)


