from threading import Thread
from comunica import *
from gestioneDB import *
from myTelegram import *
from metodi import *
from utente import *
import time

th=Thread(target=comunica)
th.start()