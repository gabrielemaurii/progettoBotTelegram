import requests

def calcola_percorso(start_latitude, start_longitude, end_latitude, end_longitude):
    api_url = "https://api.openrouteservice.org/v2/directions/driving-car"
    token = {
        "Authorization": "5b3ce3597851110001cf62487beea3b214b941d58a8bf51411e5f6e9"
    }

    params = {
        "start": f"{start_longitude},{start_latitude}",
        "end": f"{end_longitude},{end_latitude}"
    }

    response = requests.get(api_url, headers=token, params=params)
    if response.status_code == 200:
        percorso = response.json()
        return percorso
    else:
        print(f"Failed to calculate the route. Error: {response.status_code}")
        return None