def extract(message,command):
    message=message.replace(command,"")
    return message