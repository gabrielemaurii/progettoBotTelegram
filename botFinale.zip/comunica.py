from gestioneDB import *
from myTelegram import *
from metodi import *
import utente as u
import time

def comunica():
    MyTelegram = Telegram() 

    while True:
        response="errore"

        messages = MyTelegram.get_updates()
        if(messages):
            for message in messages:
                chatID = message["chat"]["id"]  
                try:
                    response=u.ricerca(chatID,message["location"]["latitude"],message["location"]["longitude"])
                    MyTelegram.sendPosition(chatID,response[0],response[1])

                except:
                    try:
                        print(message['text'])
                        if(message['text']=='/start'):
                            print(chatID)
                            response=u.start(chatID,message['chat']['username'])
                        
                        if(message['text']=='/help'):
                            response=help()
                            
                        if('/tipologia' in str(message['text'])):
                            response=u.setTipologia(chatID,extract(str(message['text']),"/tipologia "))

                        if('/capienza' in str(message['text'])):
                            response=u.setCapienza(chatID,extract(str(message['text']),"/capienza "))

                        if('/consumo' in str(message['text'])):
                            response=u.setConsumo(chatID,extract(str(message['text']),"/consumo "))
                    
                    except:
                        response="errore"
                        
                    MyTelegram.sendMessage(chatID,response)
        time.sleep(1)
        
